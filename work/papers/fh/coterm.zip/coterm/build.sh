#! /bin/bash
coqc scase.v
coqc coterm.v
